#ifndef TKLiveSync_h
#define TKLiveSync_h

void TNSInitializeLiveSync(void);

#endif /* TKLiveSync_h */
